<?php include('include/header.php');?>
<?php include('include/menu.php');?>
<?php include('include/search.php');?>

<?php

if(isset($_POST['btnSubmit'])){
    date_default_timezone_set("Asia/Dhaka");
    $reated_on = date("Y-m-d H:i:sa");
    $dept_no = $_POST['DEPARTMENT_NO'];
    $BATCH_NO = $_POST['BATCH_NO'];
    $STUDENT_ID_NUMBER = $_POST['STUDENT_ID_NUMBER'];
    $STUDENT_NAME = $_POST['STUDENT_NAME'];
    $STUDENT_PHONE = $_POST['STUDENT_PHONE'];
    $STUDENT_EMAIL = $_POST['STUDENT_EMAIL'];
    $FATHER_NAME = $_POST['FATHER_NAME'];
    $MOTHER_NAME = $_POST['MOTHER_NAME'];
    $STUDENT_PRESENT_ADDRESS = $_POST['STUDENT_PRESENT_ADDRESS'];
    $STUDENT_PERMANENT_ADDRESS = $_POST['STUDENT_PERMANENT_ADDRESS'];
    if($dept_no!="-1" && $BATCH_NO!="-1"){
    $sql = "insert into students set DEPARTMENT_NO='".$dept_no."',BATCH_NO='".$BATCH_NO."',STUDENT_ID_NUMBER='".$STUDENT_ID_NUMBER."',STUDENT_NAME='".$STUDENT_NAME."',STUDENT_PHONE='".$STUDENT_PHONE."',STUDENT_EMAIL='".$STUDENT_EMAIL."',FATHER_NAME='".$FATHER_NAME."',MOTHER_NAME='".$MOTHER_NAME."',STUDENT_PRESENT_ADDRESS='".$STUDENT_PRESENT_ADDRESS."',STUDENT_PERMANENT_ADDRESS='".$STUDENT_PERMANENT_ADDRESS."',CREATED_ON='".$reated_on."'";
    $query = mysqli_query($con,$sql);
    if($query){
        echo '<meta http-equiv="refresh" content="0">';
    }else{
        echo "not";
    }
    }else{
        echo "plz select Dept. And Batch!";
    }
}

if(isset($_POST['btnUpdate'])){
    date_default_timezone_set("Asia/Dhaka");
    $reated_on = date("Y-m-d H:i:sa");
    $id = $_GET['edit'];
    $dept_no = $_POST['DEPARTMENT_NO'];
    $BATCH_NO = $_POST['BATCH_NO'];
    $STUDENT_ID_NUMBER = $_POST['STUDENT_ID_NUMBER'];
    $STUDENT_NAME = $_POST['STUDENT_NAME'];
    $STUDENT_PHONE = $_POST['STUDENT_PHONE'];
    $STUDENT_EMAIL = $_POST['STUDENT_EMAIL'];
    $FATHER_NAME = $_POST['FATHER_NAME'];
    $MOTHER_NAME = $_POST['MOTHER_NAME'];
    $STUDENT_PRESENT_ADDRESS = $_POST['STUDENT_PRESENT_ADDRESS'];
    $STUDENT_PERMANENT_ADDRESS = $_POST['STUDENT_PERMANENT_ADDRESS'];
    if($dept_no!="-1" && $BATCH_NO!="-1"){
    $sql = "update students set DEPARTMENT_NO='".$dept_no."',BATCH_NO='".$BATCH_NO."',STUDENT_ID_NUMBER='".$STUDENT_ID_NUMBER."',STUDENT_NAME='".$STUDENT_NAME."',STUDENT_PHONE='".$STUDENT_PHONE."',STUDENT_EMAIL='".$STUDENT_EMAIL."',FATHER_NAME='".$FATHER_NAME."',MOTHER_NAME='".$MOTHER_NAME."',STUDENT_PRESENT_ADDRESS='".$STUDENT_PRESENT_ADDRESS."',STUDENT_PERMANENT_ADDRESS='".$STUDENT_PERMANENT_ADDRESS."',CREATED_ON='".$reated_on."' where STUDENT_NO='".$id."'";
    $query = mysqli_query($con,$sql);
    if($query){
        echo "<meta http-equiv='refresh' content='0;url=student_setup.php'>";
    }else{
        echo "not";
    }
    }else{
        echo "plz select Dept. And Batch!";
    }
}

if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $sql = "update students set IS_DELETED=1 where STUDENT_NO='".$id."'";
    if(mysqli_query($con,$sql)){
        echo "<meta http-equiv='refresh' content='0;url=student_setup.php'>";
    }
}

?>
<?php
if(isset($_GET['edit'])):
    $id = $_GET['edit'];
    $sql = "SELECT students.*,departments.DEPARTMENT_NAME,batches.BATCH_NAME FROM students LEFT JOIN departments ON students.DEPARTMENT_NO=departments.DEPARTMENT_NO LEFT JOIN batches ON students.BATCH_NO=batches.BATCH_NO where students.STUDENT_NO='".$id."'";
	 $query = mysqli_query($con,$sql);
	 $row = mysqli_fetch_assoc($query);

?>

                        <div class="col-xs-12">
                            <div class="page-header">
							<h1>Student Registration</h1>
						</div>
                            <form class="form-horizontal" role="form" action="" method="post">
                                <div class="col-xs-6">
					                <div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Select Department</label>
                                        <div class="col-sm-9">
										<select class="col-xs-10 col-sm-5" id="DEPARTMENT_NO" name="DEPARTMENT_NO">
										<option value="-1">Select</option>
										<?php
										
												    $sql = "select * from departments";
												    $query = mysqli_query($con,$sql);
												    foreach($query as $row1){
												        $DEPARTMENT_NO = $row['DEPARTMENT_NO'];
												        $selected = "";
												        if($DEPARTMENT_NO == $row1['DEPARTMENT_NO']){
												            $selected = "selected";
												        }
												      echo "<option value='".$row1['DEPARTMENT_NO']."' $selected >".$row1['DEPARTMENT_NAME']."</option>";
												    }
												    ?>
										</select>
									</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Select Batch</label>
                                        <div class="col-sm-9">
										<select class="col-xs-10 col-sm-5" id="BATCH_NO" name="BATCH_NO">
										<option value="-1">Select</option>
										<?php
												    $sql = "select * from batches";
												    $query = mysqli_query($con,$sql);
												    foreach($query as $row2){
												        $BATCH_NO = $row['BATCH_NO'];
												        $selected = "";
												        if($BATCH_NO == $row2['BATCH_NO']){
												            $selected = "selected";
												        }
												      echo "<option value='".$row2['BATCH_NO']."' $selected >".$row2['BATCH_NAME']."</option>";
												    }
												    ?>
										</select>
									</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="STUDENT_ID_NUMBER"> Student ID No. </label>

										<div class="col-sm-9">
											<input type="text" id="STUDENT_ID_NUMBER" name="STUDENT_ID_NUMBER" value="<?=@$row['STUDENT_ID_NUMBER']?>" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="STUDENT_NAME"> Student Name</label>

										<div class="col-sm-9">
											<input type="text" id="STUDENT_NAME" name="STUDENT_NAME" value="<?=@$row['STUDENT_NAME']?>" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="STUDENT_PHONE"> Student Phone</label>

										<div class="col-sm-9">
											<input type="text" id="STUDENT_PHONE" name="STUDENT_PHONE" value="<?=@$row['STUDENT_PHONE']?>" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									</div>
									<div class="col-xs-6">
									    <div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="STUDENT_EMAIL"> Student Email </label>

										<div class="col-sm-9">
											<input type="text" id="STUDENT_EMAIL" name="STUDENT_EMAIL" value="<?=@$row['STUDENT_EMAIL']?>" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="FATHER_NAME"> Father Name</label>

										<div class="col-sm-9">
											<input type="text" id="FATHER_NAME" name="FATHER_NAME" value="<?=@$row['FATHER_NAME']?>" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="MOTHER_NAME"> Mother Name</label>

										<div class="col-sm-9">
											<input type="text" id="MOTHER_NAME" name="MOTHER_NAME" value="<?=@$row['MOTHER_NAME']?>" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="STUDENT_PRESENT_ADDRESS"> Present Address</label>

										<div class="col-sm-9">
											<textarea id="STUDENT_PRESENT_ADDRESS" name="STUDENT_PRESENT_ADDRESS" class="col-xs-10 col-sm-5"><?=@$row['STUDENT_PRESENT_ADDRESS']?></textarea>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="STUDENT_PERMANENT_ADDRESS"> Permanent Address</label>

										<div class="col-sm-9">
											<textarea id="STUDENT_PERMANENT_ADDRESS" name="STUDENT_PERMANENT_ADDRESS" class="col-xs-10 col-sm-5"><?=@$row['STUDENT_PERMANENT_ADDRESS']?></textarea>
										</div>
									</div>
									    </div>
									    <div class="page-header">
							<h1>.</h1>
						</div>
									<div class="center">
									<input type="submit" class="btn btn-sm btn-success" name="btnUpdate" value="Update" style="margin-bottom:60px;">
									</div>
									</form>
									
					    </div>
					    
					    
	<?php
	else:
	
	?>
	    
	              <div class="col-xs-12">
                            <div class="page-header">
							<h1>Student Registration</h1>
						</div>
                            <form class="form-horizontal" role="form" action="" method="post">
                                <div class="col-xs-6">
					                <div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Select Department</label>
                                        <div class="col-sm-9">
										<select class="col-xs-10 col-sm-5" id="DEPARTMENT_NO" name="DEPARTMENT_NO">
										<option value="-1">Select</option>
										<?php
												    $sql = "select * from departments";
												    $query = mysqli_query($con,$sql);
												    
												    foreach($query as $row){
												       echo "<option value='".$row['DEPARTMENT_NO']."'>".$row['DEPARTMENT_NAME']."</option>";
												    }
												    ?>
										</select>
									</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Select Batch</label>
                                        <div class="col-sm-9">
										<select class="col-xs-10 col-sm-5" id="BATCH_NO" name="BATCH_NO">
										<option value="-1">Select</option>
										<?php
												    $sql = "select * from batches";
												    $query = mysqli_query($con,$sql);
												    
												    foreach($query as $row){
												       echo "<option value='".$row['BATCH_NO']."'>".$row['BATCH_NAME']."</option>";
												    }
												    ?>
										</select>
									</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="STUDENT_ID_NUMBER"> Student ID No. </label>

										<div class="col-sm-9">
											<input type="text" id="STUDENT_ID_NUMBER" name="STUDENT_ID_NUMBER" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="STUDENT_NAME"> Student Name</label>

										<div class="col-sm-9">
											<input type="text" id="STUDENT_NAME" name="STUDENT_NAME" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="STUDENT_PHONE"> Student Phone</label>

										<div class="col-sm-9">
											<input type="text" id="STUDENT_PHONE" name="STUDENT_PHONE" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									</div>
									<div class="col-xs-6">
									    <div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="STUDENT_EMAIL"> Student Email </label>

										<div class="col-sm-9">
											<input type="text" id="STUDENT_EMAIL" name="STUDENT_EMAIL" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="FATHER_NAME"> Father Name</label>

										<div class="col-sm-9">
											<input type="text" id="FATHER_NAME" name="FATHER_NAME" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="MOTHER_NAME"> Mother Name</label>

										<div class="col-sm-9">
											<input type="text" id="MOTHER_NAME" name="MOTHER_NAME" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="STUDENT_PRESENT_ADDRESS"> Present Address</label>

										<div class="col-sm-9">
											<textarea id="STUDENT_PRESENT_ADDRESS" name="STUDENT_PRESENT_ADDRESS" class="col-xs-10 col-sm-5"></textarea>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="STUDENT_PERMANENT_ADDRESS"> Permanent Address</label>

										<div class="col-sm-9">
											<textarea id="STUDENT_PERMANENT_ADDRESS" name="STUDENT_PERMANENT_ADDRESS" class="col-xs-10 col-sm-5"></textarea>
										</div>
									</div>
									    </div>
									    <div class="page-header">
							<h1>.</h1>
						</div>
									<div class="center">
									<input type="submit" class="btn btn-sm btn-success" name="btnSubmit" value="Submit" style="margin-bottom:60px;">
									</div>
									</form>
									
					    </div>
					    
					 
	<?php
	endif;
	?>
	
					    
					  <div class="col-xs-12">
										
										<div class="table-header">
											Results for "Deparment"
										</div>

										<!-- div.table-responsive -->

										<!-- div.dataTables_borderWrap -->
										<div>
											<div id="dynamic-table_wrapper" class="dataTables_wrapper form-inline no-footer"><div class="row"><div class="col-xs-6"><div class="dataTables_length" id="dynamic-table_length"><label>Display <select name="dynamic-table_length" aria-controls="dynamic-table" class="form-control input-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> records</label></div></div><div class="col-xs-6"><div id="dynamic-table_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control input-sm" placeholder="" aria-controls="dynamic-table"></label></div></div></div><table id="dynamic-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="dynamic-table_info">
												<thead>
													<tr role="row"><th class="center sorting_disabled" rowspan="1" colspan="1" aria-label="">
															
														</th>S.L<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Domain: activate to sort column ascending">Department Name</th>
														<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Batch Name</th>
														<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">ID NO.</th>
														<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Student Name</th>
														<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Phone Number</th>
														<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Father Name</th>
														<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Present Address</th>
														<th class="hidden-480 sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Clicks: activate to sort column ascending">Action</th>
														</tr>
												</thead>

												<tbody>
												    <?php
												    $sql = "SELECT students.*,departments.DEPARTMENT_NAME,batches.BATCH_NAME FROM students LEFT JOIN departments ON students.DEPARTMENT_NO=departments.DEPARTMENT_NO LEFT JOIN batches ON students.BATCH_NO=batches.BATCH_NO where students.IS_DELETED=0";
												    $query = mysqli_query($con,$sql);
												    $i=1;
												    foreach($query as $row){
												        echo "<tr>";
												        echo "<td>".$i."</td>";
												        echo "<td>".$row['DEPARTMENT_NAME']."</td>";
												        echo "<td>".$row['BATCH_NAME']."</td>";
												        echo "<td>".$row['STUDENT_ID_NUMBER']."</td>";
												        echo "<td>".$row['STUDENT_NAME']."</td>";
												        echo "<td>".$row['STUDENT_PHONE']."</td>";
												        echo "<td>".$row['FATHER_NAME']."</td>";
												        echo "<td>".$row['STUDENT_PRESENT_ADDRESS']."</td>";
												        echo "<td><div class='hidden-sm hidden-xs btn-group'><a class='btn btn-xs btn-info' href='student_setup.php?edit=".$row['STUDENT_NO']."'><i class='ace-icon fa fa-pencil bigger-120'></i></a><a class='btn btn-xs btn-danger' href='student_setup.php?delete=".$row['STUDENT_NO']."'><i class='ace-icon fa fa-trash-o bigger-120'></i></a></div></td>";
												        echo "</tr>";
												        $i++;
												    }
												    ?>
												</tbody>
											</table><div class="row"><div class="col-xs-6"><div class="dataTables_info" id="dynamic-table_info" role="status" aria-live="polite">Showing 1 to 10 of 23 entries</div></div><div class="col-xs-6"><div class="dataTables_paginate paging_simple_numbers" id="dynamic-table_paginate"><ul class="pagination"><li class="paginate_button previous disabled" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_previous"><a href="#">Previous</a></li><li class="paginate_button active" aria-controls="dynamic-table" tabindex="0"><a href="#">1</a></li><li class="paginate_button " aria-controls="dynamic-table" tabindex="0"><a href="#">2</a></li><li class="paginate_button " aria-controls="dynamic-table" tabindex="0"><a href="#">3</a></li><li class="paginate_button next" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_next"><a href="#">Next</a></li></ul></div></div></div></div>
										</div>
									</div>
					    
<?php include('include/footer.php');?>					    