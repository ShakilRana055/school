<?php include('include/header.php');?>
<?php include('include/menu.php');?>
<?php include('include/search.php');
$CUR_TIME = date("Y-m-d H:i:sa");
$admin='1';
$ms="";
?>

<?php
if(isset($_POST['btnSubmit'])){
   
    
    $building_no = $_POST['building_no'];
    $ROOM_NUMBER = $_POST['ROOM_NUMBER'];
    $NO_OF_BED = $_POST['NO_OF_BED'];
    $sql = "INSERT INTO ht_rooms SET `BUILDING_NO`='$building_no',`ROOM_NUMBER`='$ROOM_NUMBER',`ROOM_CAPACITY`='$NO_OF_BED',`CREATED_BY`='$admin',
    `CREATED_ON`='$CUR_TIME'";
    $query = mysqli_query($con,$sql);
    if($query){
      
        echo '<meta http-equiv="refresh" content="0">';
    }else{
        echo "not";
    }
}

if(isset($_POST['btnUpdate'])){
   
    $id = $_GET['edit'];
    
    $building_no = $_POST['building_no'];
    $ROOM_NUMBER = $_POST['ROOM_NUMBER'];
    $NO_OF_BED = $_POST['NO_OF_BED'];
    $sql = "UPDATE ht_rooms SET `BUILDING_NO`='$building_no',`ROOM_NUMBER`='$ROOM_NUMBER',`ROOM_CAPACITY`='$NO_OF_BED',`UPDATED_BY`='$admin',
    `UPDATED_ON`='$CUR_TIME' WHERE ROOM_NO='$id'";
   // echo $sql;
    $query = mysqli_query($con,$sql);
    if($query){
        $msg="ok";
       echo "<meta http-equiv='refresh' content=0;url=hostel_room_setup.php>";
    }else{
       $msg="not";
    }
}

if(isset($_GET['delete'])){
   
    $id = $_GET['delete'];
    
    $sql = "update ht_rooms set IS_DELETED='$admin',DELETED_ON='$CUR_TIME' WHERE ROOM_NO = '$id'";
    $query = mysqli_query($con,$sql);
    if($query){
        $msg="success";
        echo "<meta http-equiv='refresh' content=0;url=hostel_room_setup.php>";
        
    }else{
       $msg="failed";
    }
}



?>

<?php
if(isset($_GET['edit']))
    $id = $_GET['edit'];
    $sql = "SELECT `ROOM_NUMBER`,ht_rooms.BUILDING_NO, `ROOM_CAPACITY`,ht_buildings.BUILDING_NAME FROM `ht_rooms` LEFT JOIN ht_buildings ON
    ht_rooms.BUILDING_NO=ht_buildings.BUILDING_NO WHERE ROOM_NO='$id'";
   
	 $query = mysqli_query($con,$sql);
	 $row = mysqli_fetch_assoc($query);
	 

?>
<div class="col-xs-12">
                            <div class="page-header">
							<h1>Hostel Room Setup</h1>
						</div>
						
						<!--<p id="message">Ami Bodle Gechi Dekho</p>-->
                            <form class="form-horizontal" role="form" action="" method="post">
					<div class="form-group">
										<label class="col-sm-4 control-label no-padding-right" for="HOSTEL_NAME">Building Name</label>

            							<div class="col-sm-8">
            							   <select id="HOSTEL_NAME" name="building_no"class="col-xs-10 col-sm-5">
            							       
            							    <?php
            							        if( $row['BUILDING_NAME'] != "" )
            							        {
            							           echo "<option value= '".$row['BUILDING_NO']."'>".$row['BUILDING_NAME']."</option>" ;
            							        }
            							        $sql = "SELECT `BUILDING_NO`,`BUILDING_NAME` FROM `ht_buildings`";
                                                $query = mysqli_query($con,$sql);
                                                foreach( $query as $rows )
                                                {
                                                    echo "<option value= '".$rows['BUILDING_NO']."'>".$rows["BUILDING_NAME"]."</option>" ;
                                                }
            
            							    
            							    ?>
            							   </select>
            								<!--<input type="text" id="HOSTEL_NO" name="HOSTEL_NO" placeholder="" class="col-xs-10 col-sm-5">-->
            							</div>
									</div>
									<div class="form-group">
										<label class="col-sm-4 control-label no-padding-right" for="ROOM_NUMBER"> Room number </label>

										<div class="col-sm-8">
											<input type="text" id="ROOM_NUMBER" placeholder="" name="ROOM_NUMBER" value="<?=@$row['ROOM_NUMBER']?>" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-4 control-label no-padding-right" for="NO_OF_BED"> Capacity</label>

										<div class="col-sm-8">
											<input type="text" id="NO_OF_BED" placeholder="" name="NO_OF_BED" value="<?=@$row['ROOM_CAPACITY']?>" class="col-xs-10 col-sm-5">
										</div>
									</div>
										<?php if(isset($_GET['edit'])) {  ?>
											
										<div class="col-sm-8 pull-right">
										<input type="submit" class="btn btn-sm btn-success" name="btnUpdate" value="Update" style="margin-bottom:60px;">
										</div>
										    
									
										<?php } else { ?>

										<div class="col-sm-8 pull-right">
										<input type="submit" class="btn btn-sm btn-success" name="btnSubmit" value="Submit" style="margin-bottom:60px;">
										</div>
										
										<?php } ?>
									</form>
					    </div>
					    
					    
					    
					   <div class="col-xs-12">
										
										<div class="table-header">
											Results for "Hostel Room"
										</div>

										<!-- div.table-responsive -->

										<!-- div.dataTables_borderWrap -->
										<div>
											<div id="dynamic-table_wrapper" class="dataTables_wrapper form-inline no-footer">
											    <div class="row">
											        <div class="col-xs-6">
											            <div class="dataTables_length" id="dynamic-table_length">
											                <label>Display <select name="dynamic-table_length" aria-controls="dynamic-table" class="form-control input-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option>
											                </select> records</label>
											            </div>
											       </div>
											                <div class="col-xs-6">
											                    <div id="dynamic-table_filter" class="dataTables_filter">
											                        <label>Search:<input type="text" name="search" id="search" class="form-control input-sm" placeholder="" aria-controls="dynamic-table"></label>
											                     </div>
											                </div>
											      </div>
											    
											    <table id="dynamic_table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="dynamic-table_info">
												<thead>
													<tr role="row"><th class="center sorting_disabled" rowspan="1" colspan="1" aria-label="">S.L</th>
													    <th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Domain: activate to sort column ascending">Building Name</th>
														<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Room Number</th>
														<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Capacity</th>
														<th class="hidden-480 sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Clicks: activate to sort column ascending">Action</th>
														</tr>
												</thead>

												<tbody>
												    <?php
												    $sql = "SELECT ROOM_NO,`ROOM_NUMBER`,`ROOM_CAPACITY`,ht_buildings.BUILDING_NAME FROM `ht_rooms` LEFT JOIN ht_buildings ON 
												    ht_rooms.BUILDING_NO=ht_buildings.BUILDING_NO WHERE ht_rooms.IS_DELETED='0'";
												    $query = mysqli_query($con,$sql);
												    $i=1;
												    foreach($query as $row){
												        echo "<tr>";
												        echo "<td>".$i."</td>";
												        echo "<td>".$row['BUILDING_NAME']."</td>";
												        echo "<td>".$row['ROOM_NUMBER']."</td>";
												        echo "<td>".$row['ROOM_CAPACITY']."</td>";
												        echo "<td><div class='hidden-sm hidden-xs btn-group'><a class='btn btn-xs btn-info' href='hostel_room_setup.php?edit=".$row['ROOM_NO']."'><i class='ace-icon fa fa-pencil bigger-120'></i></a><a class='btn btn-xs btn-danger' href='hostel_room_setup.php?delete=".$row['ROOM_NO']."'><i class='ace-icon fa fa-trash-o bigger-120'></i></a></div></td>";
												        echo "</tr>";
												        $i++;
												    }
												    ?>
												</tbody>
											</table><div class="row"><div class="col-xs-6"><div class="dataTables_info" id="dynamic-table_info" role="status" aria-live="polite">Showing 1 to 10 of 23 entries</div></div><div class="col-xs-6"><div class="dataTables_paginate paging_simple_numbers" id="dynamic-table_paginate"><ul class="pagination"><li class="paginate_button previous disabled" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_previous"><a href="#">Previous</a></li><li class="paginate_button active" aria-controls="dynamic-table" tabindex="0"><a href="#">1</a></li><li class="paginate_button " aria-controls="dynamic-table" tabindex="0"><a href="#">2</a></li><li class="paginate_button " aria-controls="dynamic-table" tabindex="0"><a href="#">3</a></li><li class="paginate_button next" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_next"><a href="#">Next</a></li></ul></div></div></div></div>
										</div>
									</div>
					    
<?php include('include/footer.php');?>	


<script>
    $("#search").on("keyup",function(){
        
        var values=$(this).val();
        
        $("#dynamic_table tr").each(function(){
            
            var id=$(this).find("td").text();
                if(id.indexOf(values)!==0 && id.toLowerCase().indexOf(values.toLowerCase())<=0)
                {
                    
                    $(this).hide();
                }
                else{
                    $(this).show();
                }
            
        });
        
    });
    
</script>

