<?php include('include/header.php');?>
<?php include('include/menu.php');?>
<?php include('include/search.php');?>

<?php
    $cur = date("Y-m-d h:i:s") ;
    $msg = "" ;
    if( isset( $_POST['btnSubmit'] )  )
    {
        $ROOM_NUMBER = $_POST['ROOM_NUMBER'] ;
        $BED_CATEGORY = $_POST['BED_CATEGORY'] ;
        $BED_RENT = $_POST['BED_RENT'] ;
        $VALID_FROM = $_POST['VALID_FROM'] ;
        
        $query ="INSERT INTO ht_beds SET `ROOM_NO` = '$ROOM_NUMBER', `BED_RENT` = '$BED_RENT', `BED_CATEGORY` = '$BED_CATEGORY', `IS_ACTIVE` = 1 , `VALID_FROM` = '$VALID_FROM', `CREATED_ON` = '$cur'" ;
        $result = mysqli_query( $con , $query ) ;
        
        $msg = $result ? "inserted":"error";
    }

?>



<div class="col-xs-12" >
	<div class="page-header">
		<h1>Hostel Daily Expense</h1>
	<div class="hr hr-24"></div>
	<form class="form-horizontal" role="form" action="" method="post" >
		<div class = "col-sm-6">
    		<div class="form-group">
    			<label class="col-md-4 control-label no-padding-right" for="EmployeeNo">Employee Name</label>
    			<div class="col-md-8">
    				<select id="EmployeeNo" name="EmployeeNo"class="form-control">
    				    <option value="1">Somrat Akbor</option>
    				       
    				</select>
    			</div>
    		</div>
 
	    </div>
	    
	    <div class = "col-sm-6">
			<div class="form-group">
				<label class="col-md-4 control-label no-padding-right" for="ExpenseDate">Date</label>
				<div class="col-md-8">
					<input type="date" id="ExpenseDate" placeholder="" name="ExpenseDate" class="form-control">
					</div>
				</div>
	
		</div>
		
		    
		    

		
		
			
	</form>
	<div class="hr hr-24"></div>
</div>
	</div>		
			
			
<div class="col-xs-12" style="margin-top:10px;">
	
	<form class="form-horizontal" role="form" action="" method="post">
			<div class = "col-sm-6">
            		<div class="form-group">
        				<label class="col-md-4 control-label no-padding-right" for="BED_RENT">Description</label>
        				<div class="col-md-8">
        					<textarea type="date" id="description"  name="description" class="form-control"></textarea>
        					</div>
        		  </div>
        		  <div class="form-group">
        				<label class="col-md-4 control-label no-padding-right" for="BED_RENT">Amount</label>
        				<div class="col-md-8">
        					<input type="text" id="amount"  name="amount" class="form-control">
        					</div>
        		  </div>
	    </div>
	    
	    <div class = "col-sm-6">
			<div class="form-group">
				<label class="col-md-4 control-label no-padding-right" for="BED_RENT">Bill No</label>
				<div class="col-md-8">
					<input type="text" id="bill_no" placeholder="" name="bill_no" class="form-control">
					</div>
				</div>
	
		</div>
		<div class="center">
			<input type="button" class="btn btn-sm btn-success" name="btnAdd" id = "btnAdd" value="Add" style="margin-bottom:60px;">
		</div>
			
		</form>
	<div class="hr "></div>
</div>	
<div class="col-xs-12">
	<div class="table-header">
		Results for Expenses
	</div>

	<div>
		<div id="dynamic-table_wrapper" class="dataTables_wrapper form-inline no-footer">

		    <table id="dynamic_table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="dynamic-table_info">
    			<thead>
    				<tr role="row">
    				    <th class="center sorting_disabled" rowspan="1" colspan="1" aria-label="">S.L</th>
    				    <th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Domain: activate to sort column ascending">Description</th>
    					<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Amount</th>
    					<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Domain: activate to sort column ascending">Bill No</th>
    					<th class="hidden-480 sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Clicks: activate to sort column ascending">Action</th>
    				</tr>
    			</thead>
    
        		<tbody id = "recordList">
                
        		</tbody>
        		<tfoot>
        		    <tr role="row">
        		        <th class="center sorting_disabled" rowspan="1" colspan="1" aria-label=""></th>
        		        <th class="center sorting_disabled" rowspan="1" colspan="1" aria-label="">Amount</th>
        		        <th class="center sorting_disabled" rowspan="1" colspan="1" aria-label="" id = "totalAmount"></th>
        		        <th class="center sorting_disabled" rowspan="1" colspan="1" aria-label=""></th>
        		        <th class="center sorting_disabled" rowspan="1" colspan="1" aria-label=""></th>
        		    </tr>
        		</tfoot>
		    </table>
		   
		</div>
	</div>
	<div class="center" style="margin-top:15px;">
			<input type="button" class="btn btn-sm btn-success" id = "btnSubmit" name="btnSubmit" value="Submit" style="margin-bottom:60px;">
	</div>
</div>
			
		


<?php include('include/footer.php');?>	
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script>
    
        var description = [];
        var amount = [] ;
        var bill_no = [] ;
    
    function clearBtnAdd()
    {
        $("#description").val("");
        $("#amount").val("");
        $("#bill_no").val("") ;
    }
    
    function printTable( )
    {
        var html = "" ;
        var finalAmount = 0 ;
        for( var i = 0 ; i < description.length ; i ++ )
        {
            finalAmount += Number( amount[i] ) ;
            var sl = i + 1 ;
            html += "<tr>" ;
            html += "<td> "+ sl +"</td><td>"+description[i]+"</td><td>"+amount[i]+"</td><td>"+bill_no[i]+"</td>";
            html += "<td><input type = 'button' class = 'btn btn-success editThis' index = "+i+" value = 'Edit'><input type = 'button' class = 'btn btn-danger deleteThis' index = "+i+" value = 'Delete'><td>";
            html += "</tr>";
        }
        $("#recordList").html(html) ;
        $("#totalAmount").text( finalAmount ) ;
        clearBtnAdd() ;
    }
    
    function saveExpense( description, amount, bill_no , EmployeeNo , ExpenseDate )
    {
        var Finalamount = $("#totalAmount").val( ) ;
        $.ajax({ 
            url:"ajax/saveExpense.php",
            method:"post",
            data: ({ "description":description.toString(), "amount":amount.toString(), "bill_no": bill_no.toString(), "EmployeeNo": EmployeeNo, "ExpenseDate":ExpenseDate, "Finalamount":Finalamount }),
            dataType: "html",
            success: function( Data )
            {
                alert( "Successfull" ) ;
            }
        }) ;
    }
    
    $(document).ready( function( ){ 
        
        $("#btnSubmit").on("click", function( ) { 
            var EmployeeNo = $("#EmployeeNo").val();
            var ExpenseDate = $("#ExpenseDate").val();
            saveExpense( description, amount, bill_no , EmployeeNo , ExpenseDate ) ;
        }) ;
        
        $("#btnAdd").on("click", function( ) { 
            var desc = $("#description").val().trim() ;
            var taka = $("#amount").val().trim() ;
            var bill = $("#bill_no").val().trim() ;
            
            description.push(desc ) ;
            amount.push( taka ) ;
            bill_no.push( bill) ;
            printTable() ;
        }) ;
        
        $(document).on("click", ".deleteThis", function( ) { 
            var index = $(this).attr("index") ;
            description.splice(index , 1 ) ;
            amount.splice(index , 1 ) ;
            bill_no.splice(index , 1 ) ;
            printTable() ;
        }) ;
        
        $(document).on("click" , ".editThis", function( ) { 
            var index = $(this).attr("index") ;
            $("#description").val( description[index] );
            $("#amount").val( amount[index] );
            $("#bill_no").val( bill_no[index] ) ;
            
        }) ;
        
    }) ;
    
</script>
