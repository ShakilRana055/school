<?php include('include/header.php');?>
<?php include('include/menu.php');?>
<?php include('include/search.php');?>
<?php

    date_default_timezone_set("Asia/Dhaka");
    $time_on = date("Y-m-d H:i:sa");
    $admin = "admin1";
    
    
if(isset($_POST['btnSubmit'])){
    $BUILDING_NAME = $_POST['BUILDING_NAME'];
    $BUILDING_LOCATION = $_POST['BUILDING_LOCATION'];
    $BUILDING_FOR = $_POST['BUILDING_FOR'];
    $CREATED_BY = $admin;
    $sql = "INSERT INTO ht_buildings SET BUILDING_NAME='".$BUILDING_NAME."',BUILDING_LOCATION='".$BUILDING_LOCATION."',BUILDING_FOR='".$BUILDING_FOR."',CREATED_BY='".$admin."', CREATED_ON='".$time_on."'";
    $query = mysqli_query($con,$sql);
    
    if($query){
        echo '<meta http-equiv="refresh" content="0">';
    }else{
        echo "problem's occured";
    }
}
    //ht_buildings BUILDING_NO BUILDING_NAME BUILDING_LOCATION BUILDING_FOR 	CREATED_BY CREATED_ON
if(isset($_POST['btnUpdate'])){
    $id = $_GET['edit'];
    $BUILDING_NAME = $_POST['BUILDING_NAME'];
    $BUILDING_LOCATION = $_POST['BUILDING_LOCATION'];
    $BUILDING_FOR = $_POST['BUILDING_FOR'];
    $sql = "UPDATE ht_buildings SET BUILDING_NAME='".$BUILDING_NAME."',BUILDING_LOCATION='".$BUILDING_LOCATION."',BUILDING_FOR='".$BUILDING_FOR."' WHERE 	BUILDING_NO = '$id'";
    $query = mysqli_query($con,$sql);
    if($query){
        echo '<meta http-equiv="refresh" content="0";url=building_setup.php>';
    }else{
        echo "not";
    }
}

if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    
    $sql = "update ht_buildings set IS_DELETED=1 where BUILDING_NO = '$id'";
    $query = mysqli_query($con,$sql);
    if($query){
        echo "<meta http-equiv='refresh' content=0;url=building_setup.php>";
    }else{
        echo "not";
    }
}


?>

<?php
if(isset($_GET['edit'])):
    $id = $_GET['edit'];
    $sql = "SELECT * from ht_buildings WHERE IS_DELETED=0 && BUILDING_NO = '$id'";
	 $query = mysqli_query($con,$sql);
	 $row = mysqli_fetch_assoc($query);
?>
    <div class="col-xs-12">
            <!--//ht_buildings BUILDING_NO BUILDING_NAME BUILDING_LOCATION BUILDING_FOR 	CREATED_BY CREATED_ON-->
        <div class="page-header">
			<h1>Hostel Setup</h1>
		</div>
        <form class="form-horizontal" role="form" action="" method="post">
			<div class="form-group">
				<label class="col-sm-3 control-label no-padding-right" for="BUILDING_NAME"> Building Name</label>

				<div class="col-sm-9">
					<input type="text" id="BUILDING_NAME" value="<?=@$row['BUILDING_NAME']?>" name="BUILDING_NAME" placeholder="" class="col-xs-10 col-sm-5">
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label no-padding-right" for="BUILDING_LOCATION"> BUILDING LOCATION </label>

					<div class="col-sm-9">
						<input type="text" id="BUILDING_LOCATION" value="<?=@$row['BUILDING_LOCATION']?>" name="BUILDING_LOCATION" placeholder="" class="col-xs-10 col-sm-5">
					</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label no-padding-right" for="BUILDING_FOR"> BUILDING FOR </label>

					<div class="col-sm-4">
						<!--<input type="text" id="BUILDING_FOR"  name="BUILDING_FOR" placeholder="" class="col-xs-10 col-sm-5">-->
						<select name="BUILDING_FOR" class="form-control input-sm">
    				            <option value="">-select-</option>
        		                <option value="Male">Male</option>
        		                <option value="Female">Female</option>
        		        </select>
					</div>
			</div>
			<div class="center">
				<input type="submit" class="btn btn-sm btn-success" name="btnUpdate" value="Update" style="margin-bottom:60px;">
			</div>
		</form>
    </div>
					    
					    
<?php
	else:
?>				
	
	<div class="col-xs-12">
        <div class="page-header">
			<h1>Hostel Building Setup</h1>
		</div>
        <form class="form-horizontal" role="form" action="" method="post">
    		<div class="form-group">
    			<label class="col-sm-3 control-label no-padding-right" for="BUILDING_NAME">BUILDING NAME</label>
    
    			<div class="col-sm-9">
    				<input type="text" id="BUILDING_NAME" name="BUILDING_NAME" placeholder="" class="col-xs-10 col-sm-5">
    			</div>
    		</div>
    		<div class="form-group">
    			<label class="col-sm-3 control-label no-padding-right" for="BUILDING_LOCATION">BUILDING LOCATION</label>
    
    			<div class="col-sm-9">
    				<input type="text" id="BUILDING_LOCATION" name="BUILDING_LOCATION" placeholder="" class="col-xs-10 col-sm-5">
    			</div>
    		</div>
    		<div class="form-group">
    
    			<label class="col-sm-3 control-label no-padding-right" for="BUILDING_FOR">BUILDING FOR </label>
    			<div class="col-sm-4">
    				<select name="BUILDING_FOR" class="form-control input-sm">
    				            <option value="">-Select-</option>
        		                <option value="Male">Male</option>
        		                <option value="Female">Female</option>
        		    </select>
    			</div>
    		</div>
    		<div class="center">
    			<input type="submit" class="btn btn-sm btn-success" name="btnSubmit" value="Submit" style="margin-bottom:60px;">
    		</div>
	    </form>
	</div>
	
<?php
endif;
?>


<div class="col-xs-12">
	<div class="table-header">
		Results for Buildings
	</div>

	<!-- div.table-responsive -->

	<!-- div.dataTables_borderWrap -->
	<div>
		<div id="dynamic-table_wrapper" class="dataTables_wrapper form-inline no-footer">
		    <div class="row">
		        <div class="col-xs-6">
    		        <div class="dataTables_length" id="dynamic-table_length">
    		            <label>Display 
        		            <select name="dynamic-table_length" aria-controls="dynamic-table" class="form-control input-sm">
        		                <option value="10">10</option>
        		                <option value="25">25</option>
        		                <option value="50">50</option>
        		                <option value="100">100</option>
        		            </select> records
    		            </label>
    		        </div>
		          </div>
		          <div class="col-xs-6">
		              <div id="dynamic-table_filter" class="dataTables_filter">
		                    <label>Search:
		                        <input name="search" id = "search" type="search" class="form-control input-sm" placeholder="" aria-controls="dynamic-table">
		                    </label>
		              </div>
		         </div>
		    </div>
		    <table id="dynamic_table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="dynamic-table_info">
    			<thead>
    				<tr role="row">
    				    <th class="center sorting_disabled" rowspan="1" colspan="1" aria-label="">S.L</th>
    				    <th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Domain: activate to sort column ascending">Building Name</th>
    					<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Building Location</th>
    					<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Domain: activate to sort column ascending">Building For</th>
    					<th class="hidden-480 sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Clicks: activate to sort column ascending">Action</th>
    				</tr>
    			</thead>
    
        		<tbody>
<?php
        			$sql = "select * from ht_buildings where IS_DELETED=0";
        			$query = mysqli_query($con,$sql);
        			$i=1;
        			foreach($query as $row){
        			    
    //ht_buildings BUILDING_NO BUILDING_NAME BUILDING_LOCATION BUILDING_FOR 	CREATED_BY CREATED_ON
            			echo "<tr>";
            			echo "<td>".$i."</td>";
            			echo "<td>".$row['BUILDING_NAME']."</td>";
            			echo "<td>".$row['BUILDING_LOCATION']."</td>";
            			echo "<td>".$row['BUILDING_FOR']."</td>";
            			echo "<td>
                			    <div class='hidden-sm hidden-xs btn-group'>
                			        <a class='btn btn-xs btn-info' href='building_setup.php?edit=".$row['BUILDING_NO']."'>
                			            <i class='ace-icon fa fa-pencil bigger-120'></i>
                			        </a>
                			        <a class='btn btn-xs btn-danger' href='building_setup.php?delete=".$row['BUILDING_NO']."'>
                			            <i class='ace-icon fa fa-trash-o bigger-120'></i>
                			        </a>
                			     </div>
            			     </td>";
            			echo "</tr>";
            			$i++;
        			}
?>
        		</tbody>
		    </table>
		    <div class="row">
		        <div class="col-xs-6">
		            <div class="dataTables_info" id="dynamic-table_info" role="status" aria-live="polite">Showing 1 to 10 of 23 entries
		            </div>
		        </div>
		            <div class="col-xs-6">
		                <div class="dataTables_paginate paging_simple_numbers" id="dynamic-table_paginate">
		                    <ul class="pagination">
		                        <li class="paginate_button previous disabled" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_previous">
		                            <a href="#">Previous</a>
		                        </li>
		                        <li class="paginate_button active" aria-controls="dynamic-table" tabindex="0">
		                              <a href="#">1</a>
		                        </li>
		                        <li class="paginate_button " aria-controls="dynamic-table" tabindex="0">
		                              <a href="#">2</a>
		                        </li>
		                        <li class="paginate_button " aria-controls="dynamic-table" tabindex="0">
		                              <a href="#">3</a>
		                        </li>
		                        <li class="paginate_button next" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_next">
		                               <a href="#">Next</a>
		                        </li>
		                     </ul>
		               </div>
		          </div>
		     </div>
		</div>
	</div>
</div>
					    
<?php include('include/footer.php');?>
<script>
    $("#search").on("keyup",function(){
        
        var values=$(this).val();
        
        $("#dynamic_table tr").each(function(){
            
            var id=$(this).find("td").text();
                if(id.indexOf(values)!==0 && id.toLowerCase().indexOf(values.toLowerCase())<=0)
                {
                    
                    $(this).hide();
                }
                else{
                    $(this).show();
                }
            
        });
        
    });
    
</script>