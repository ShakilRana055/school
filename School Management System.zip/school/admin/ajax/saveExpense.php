<?php
    
    $cur = date("Y-m-d h:i:s") ;
    
    if( isset( $_POST['check']) )
    {
        include( "../../config/db_connection.php" ) ;
        $description = explode( "," , $_POST['description'] ) ;
        $amount = explode( "," , $_POST['amount'] ) ;
        $bill_no = explode( "," , $_POST['bill_no'] ) ;
        $EmployeeNo = $_POST['EmployeeNo'] ;
        $ExpenseDate = $_POST['ExpenseDate'] ;
        $Finalamount = $_POST['Finalamount'] ;
        $query = "INSERT INTO ht_daily_expenses_master SET `DATE` = '$ExpenseDate', `TOTAL_AMOUNT` = '$Finalamount', `EMPLOYEE_NO` = '$EmployeeNo', `CREATED_ON` = '$cur'";
        mysqli_autocommit( $con , true ) ;
        
        // insert into ht_daily_expenses_master
            mysqli_query( $con , $query ) ;
            $last_id = mysqli_insert_id( $con ) ;
        // 
        
        // insert into details
            $result = "" ;
            for( $i = 0 ; $i < count( $description ) ; $i ++ )
            {
                $Desc = $description[$i] ;
                $Individual =  $amount[$i] ;
                $BillNo =  $bill_no[$i] ;
                $sql = "INSERT INTO ht_daily_expenses_details SET `HT_DAILY_EXPENSES_MASTER_NO` = '$last_id', `DESCRIPTION` = '$Desc', `AMOUNT` = '$Individual', `BILL_NO` = '$BillNo', `CREATED_ON` = '$cur'";
                $result = mysqli_query( $con , $sql ) ;
            }
        
        // 
        
        mysqli_close( $con ) ;
    }
    
?>