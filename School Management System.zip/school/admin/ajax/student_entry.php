<?php
    
    if( isset( $_POST['check']) )
    {
        include( "../../config/db_connection.php" ) ;
        $roomNo = $_POST['roomNo'] ;
        $query = "SELECT `BED_NO`, `BED_RENT`, `BED_CATEGORY` FROM `ht_beds` WHERE `ROOM_NO` = '$roomNo'" ;
        echo $query ;
        $result = mysqli_query( $con , $query );
        foreach( $result as $value )
        {
            echo "<option value = '".$value['BED_NO']."'>".$value['BED_CATEGORY']."( ".$value['BED_RENT']." )</option>" ;
        }
    }
    
    if( isset( $_POST['getBuildingNumber']) )
    {
        include( "../../config/db_connection.php" ) ;
        $BuildingNumber = $_POST['BuildingNumber'] ;
        
        $query = "SELECT `ROOM_NO`, `ROOM_NUMBER` FROM ht_rooms WHERE `BUILDING_NO` = '$BuildingNumber' " ;
        echo $query ;
        $result = mysqli_query( $con , $query );
        foreach( $result as $value )
        {
            echo "<option value = '".$value['ROOM_NO']."'>".$value['ROOM_NUMBER']."</option>" ;
        }
    }
    
?>