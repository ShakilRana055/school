<?php include('include/header.php');?>
<?php include('include/menu.php');?>
<?php include('include/search.php');?>

<?php
if(isset($_POST['btnSubmit'])){
    date_default_timezone_set("Asia/Dhaka");
    $reated_on = date("Y-m-d H:i:sa");
    $dept_no = $_POST['DEPARTMENT_NO'];
    $SUBJECT_TITLE = $_POST['SUBJECT_TITLE'];
    $SUBJECT_CODE = $_POST['SUBJECT_CODE'];
    $SUBJECT_CREDIT = $_POST['SUBJECT_CREDIT'];
    if($dept_no!="-1"){
    $sql = "insert into subjects set DEPARTMENT_NO='".$dept_no."',SUBJECT_CODE='".$SUBJECT_CODE."',SUBJECT_TITLE='".$SUBJECT_TITLE."',SUBJECT_CREDIT='".$SUBJECT_CREDIT."',CREATED_ON='".$reated_on."'";
    $query = mysqli_query($con,$sql);
    if($query){
        echo '<meta http-equiv="refresh" content="0">';
    }else{
        echo "not";
    }
    }else{
        echo "Please Select Dept.!";
    }
}

if(isset($_POST['btnUpdate'])){
    date_default_timezone_set("Asia/Dhaka");
    $reated_on = date("Y-m-d H:i:sa");
    $id = $_GET['edit'];
    $dept_no = $_POST['DEPARTMENT_NO'];
    $SUBJECT_TITLE = $_POST['SUBJECT_TITLE'];
    $SUBJECT_CODE = $_POST['SUBJECT_CODE'];
    $SUBJECT_CREDIT = $_POST['SUBJECT_CREDIT'];
    if($dept_no!="-1"){
    $sql = "update subjects set DEPARTMENT_NO='".$dept_no."',SUBJECT_CODE='".$SUBJECT_CODE."',SUBJECT_TITLE='".$SUBJECT_TITLE."',SUBJECT_CREDIT='".$SUBJECT_CREDIT."',UPDATED_ON='".$reated_on."' where SUBJECT_NO='".$id."'";
    $query = mysqli_query($con,$sql);
    if($query){
        echo "<meta http-equiv='refresh' content='0;url=subject_setup.php'>";
    }else{
        echo "not";
    }
    }else{
        echo "Please Select Dept.!";
    }
}

if(isset($_GET['delete'])){
    date_default_timezone_set("Asia/Dhaka");
    $deleted_on = date("Y-m-d H:i:sa");
    $id = $_GET['delete'];
    
    $sql = "update subjects set IS_DELETED=1,DELETED_ON='$deleted_on' where SUBJECT_NO = '$id'";
    $query = mysqli_query($con,$sql);
    if($query){
        echo "<meta http-equiv='refresh' content='0;url=subject_setup.php'>";
    }else{
        echo "not";
    }
}

?>

<?php
if(isset($_GET['edit'])):
    $id = $_GET['edit'];
    $sql = "select * from subjects where SUBJECT_NO = '$id'";
	 $query = mysqli_query($con,$sql);
	 $row = mysqli_fetch_assoc($query);

?>
                        <div class="col-xs-12">
                            <div class="page-header">
							<h1>Subject Setup</h1>
						</div>
                            <form class="form-horizontal" role="form" action="" method="post">
					<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Select Department</label>
                                        <div class="col-sm-9">
										<select class="col-xs-10 col-sm-5" id="DEPARTMENT_NO" name="DEPARTMENT_NO">
										    <option value="-1">Select</option>
										<?php
												    $sql = "select * from departments";
												    $query = mysqli_query($con,$sql);
												    
												    foreach($query as $row1){
												        $DEPARTMENT_NO = $row['DEPARTMENT_NO'];
												        $selected="";
												        if($DEPARTMENT_NO==$row1['DEPARTMENT_NO']){
												            $selected="selected";
												        }
												       echo "<option value='".$row1['DEPARTMENT_NO']."' $selected>".$row1['DEPARTMENT_NAME']."</option>";
												    }
												    ?>
										</select>
									</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="SUBJECT_CODE" name="SUBJECT_CODE"> Subject Code </label>

										<div class="col-sm-9">
											<input type="text" id="SUBJECT_CODE" value="<?=@$row['SUBJECT_CODE']?>" name="SUBJECT_CODE" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="SUBJECT_TITLE"> Subject Title</label>

										<div class="col-sm-9">
											<input type="text" id="SUBJECT_TITLE" value="<?=@$row['SUBJECT_TITLE']?>" name="SUBJECT_TITLE" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="SUBJECT_CREDIT">Credit</label>

										<div class="col-sm-9">
											<input type="text" id="SUBJECT_CREDIT" value="<?=@$row['SUBJECT_CREDIT']?>" name="SUBJECT_CREDIT" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
								    <div class="center">
									<input type="submit" class="btn btn-sm btn-success" name="btnUpdate" value="Update" style="margin-bottom:60px;">
									</div>
									</form>
									
					    </div>
					    
<?php
else:
?>

<div class="col-xs-12">
                            <div class="page-header">
							<h1>Subject Setup</h1>
						</div>
                            <form class="form-horizontal" role="form" action="" method="post">
					<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Select Department</label>
                                        <div class="col-sm-9">
										<select class="col-xs-10 col-sm-5" id="DEPARTMENT_NO" name="DEPARTMENT_NO">
										    <option value="-1">Select</option>
										<?php
												    $sql = "select * from departments";
												    $query = mysqli_query($con,$sql);
												    
												    foreach($query as $row){
												       echo "<option value='".$row['DEPARTMENT_NO']."'>".$row['DEPARTMENT_NAME']."</option>";
												    }
												    ?>
										</select>
									</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="SUBJECT_CODE" name="SUBJECT_CODE"> Subject Code </label>

										<div class="col-sm-9">
											<input type="text" id="SUBJECT_CODE" name="SUBJECT_CODE" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="SUBJECT_TITLE"> Subject Title</label>

										<div class="col-sm-9">
											<input type="text" id="SUBJECT_TITLE" name="SUBJECT_TITLE" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="SUBJECT_CREDIT">Credit</label>

										<div class="col-sm-9">
											<input type="text" id="SUBJECT_CREDIT" name="SUBJECT_CREDIT" placeholder="" class="col-xs-10 col-sm-5">
										</div>
									</div>
								    <div class="center">
									<input type="submit" class="btn btn-sm btn-success" name="btnSubmit" value="Submit" style="margin-bottom:60px;">
									</div>
									</form>
									
					    </div>
					    
<?php
endif;
?>
					    
					    <div class="col-xs-12">
										
										<div class="table-header">
											Results for "Subject"
										</div>

										<!-- div.table-responsive -->

										<!-- div.dataTables_borderWrap -->
										<div>
											<div id="dynamic-table_wrapper" class="dataTables_wrapper form-inline no-footer"><div class="row"><div class="col-xs-6"><div class="dataTables_length" id="dynamic-table_length"><label>Display <select name="dynamic-table_length" aria-controls="dynamic-table" class="form-control input-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> records</label></div></div><div class="col-xs-6"><div id="dynamic-table_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control input-sm" placeholder="" aria-controls="dynamic-table"></label></div></div></div><table id="dynamic-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="dynamic-table_info">
												<thead>
													<tr role="row"><th class="center sorting_disabled" rowspan="1" colspan="1" aria-label="">
															
														S.L</th><th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Domain: activate to sort column ascending">Subject Code</th>
														<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Department Name</th>
														<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Subject Title</th>
														<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Credit Hour</th>
														<th class="hidden-480 sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Clicks: activate to sort column ascending">Action</th>
														</tr>
												</thead>

												<tbody>
												    <?php
												    $sql = "SELECT subjects.*,departments.DEPARTMENT_NAME FROM `subjects` LEFT JOIN departments ON subjects.DEPARTMENT_NO=departments.DEPARTMENT_NO where subjects.IS_DELETED=0";
												    $query = mysqli_query($con,$sql);
												    $i=1;
												    foreach($query as $row){
												        echo "<tr>";
												        echo "<td>".$i."</td>";
												        echo "<td>".$row['SUBJECT_CODE']."</td>";
												        echo "<td>".$row['DEPARTMENT_NAME']."</td>";
												        echo "<td>".$row['SUBJECT_TITLE']."</td>";
												        echo "<td>".$row['SUBJECT_CREDIT']."</td>";
												        echo "<td><div class='hidden-sm hidden-xs btn-group'><a class='btn btn-xs btn-info' href='subject_setup.php?edit=".$row['SUBJECT_NO']."'><i class='ace-icon fa fa-pencil bigger-120'></i></a><a class='btn btn-xs btn-danger' href='subject_setup.php?delete=".$row['SUBJECT_NO']."'><i class='ace-icon fa fa-trash-o bigger-120'></i></a></div></td>";
												        echo "</tr>";
												        $i++;
												    }
												    ?>
												</tbody>
											</table><div class="row"><div class="col-xs-6"><div class="dataTables_info" id="dynamic-table_info" role="status" aria-live="polite">Showing 1 to 10 of 23 entries</div></div><div class="col-xs-6"><div class="dataTables_paginate paging_simple_numbers" id="dynamic-table_paginate"><ul class="pagination"><li class="paginate_button previous disabled" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_previous"><a href="#">Previous</a></li><li class="paginate_button active" aria-controls="dynamic-table" tabindex="0"><a href="#">1</a></li><li class="paginate_button " aria-controls="dynamic-table" tabindex="0"><a href="#">2</a></li><li class="paginate_button " aria-controls="dynamic-table" tabindex="0"><a href="#">3</a></li><li class="paginate_button next" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_next"><a href="#">Next</a></li></ul></div></div></div></div>
										</div>
									</div>
					    
<?php include('include/footer.php');?>					    