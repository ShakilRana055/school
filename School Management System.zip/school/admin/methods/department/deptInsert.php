<?php include('../../../config/db_connection.php');

if(isset($_POST['departmentInsert']) && $_POST['departmentInsert']!=""){
    deptInsert($_POST['DEPARTMENT_CODE'],$_POST['DEPARTMENT_NAME'],$con);
    
}

function deptInsert($dept_code,$dept_name,$con){
    date_default_timezone_set("Asia/Dhaka");
    $created_on = date("Y-m-d H:i:sa");
    $sql = "insert into departments set DEPARTMENT_CODE='".$dept_code."',DEPARTMENT_NAME='".$dept_name."',CREATED_ON='".$created_on."'";
    if(mysqli_query($con,$sql)){
        echo 1;
    }
}


?>