<?php include('include/header.php');?>
<?php include('include/menu.php');?>
<?php include('include/search.php');?>

<?php
    $cur = date("Y-m-d h:i:s") ;
    $msg = "" ;
    if( isset( $_POST['btnSubmit'] )  )
    {
        $student_id = $_POST['student_id'] ;
        $building_number = $_POST['building_number'] ;
        $ROOM_NUMBER = $_POST['ROOM_NUMBER'] ;
        $bed_number = $_POST['bed_number'] ;
        $VALID_FROM = $_POST['VALID_FROM'] ;
        
        $getDate = $VALID_FROM ;
        $convert = explode( "-", $getDate ) ;
        
        $query = "INSERT INTO ht_students SET `STUDENT_NO` = '$student_id', `BED_NO` = '$bed_number', `ROOM_NO` = '$ROOM_NUMBER', `BUILDING_NO` = '$building_number', 
        `HT_STUDENT_VALID_FROM` = '$VALID_FROM', `HT_STUDENT_MONTH` = '$convert[0]', `HT_STUDENT_YEAR` = '$convert[1]', `CREATED_ON` = '$cur'";
        $result = mysqli_query( $con , $query ) ;
        
        $msg = $result ? "inserted":"error";
    }

?>

<?php
    if( isset( $_GET['delete'] ) ) 
    {
        $id = $_GET['delete'];
        $query = "UPDATE ht_students SET IS_DELETED = 1 WHERE HT_STUDENT_NO = $id" ;
        echo $query ;
        $result = mysqli_query( $con , $query ) ;
        
        $msg = $result ? "Deleted":"error";
    }

?>

<div class="col-xs-12">
	<div class="page-header">
		<h1>Student Entry Setup</h1>
	</div>
	<form class="form-horizontal" role="form" action="" method="post">
		<div class = "col-sm-6">
		    
		    <div class="form-group">
    			<label class="col-md-4 control-label no-padding-right" for="student_id">Student ID</label>
    			<div class="col-md-8">
    				<select id="student_id" name="student_id"class="form-control">
    				    <option>Please Select one</option>
    				        <?php
    				            $query = "SELECT STUDENT_NO , STUDENT_ID_NUMBER,STUDENT_NAME FROM students" ;
                                $result  = mysqli_query( $con , $query ) ;
                                foreach( $result as $val )
                                {
                                    echo "<option value = '".$val['STUDENT_NO']."'>".$val['STUDENT_ID_NUMBER']."( ".$val['STUDENT_NAME']." )</option>" ;
                                }
    				        ?>
    				    
    				</select>
    			</div>
    		</div>
    		
    		<div class="form-group">
    			<label class="col-md-4 control-label no-padding-right" for="building_number">Building Name</label>
    			<div class="col-md-8">
    				<select id="building_number" name="building_number"class="form-control">
    				    <option>Please Select one</option>
    				           <?php
    				            $query = "SELECT BUILDING_NO , BUILDING_NAME FROM ht_buildings" ;
                                $result  = mysqli_query( $con , $query ) ;
                                foreach( $result as $val )
                                {
                                    echo "<option value = '".$val['BUILDING_NO']."'>".$val['BUILDING_NAME']."</option>" ;
                                }
    				        ?>
    				    
    				</select>
    			</div>
    		</div>
		    
    		<div class="form-group">
    			<label class="col-md-4 control-label no-padding-right" for="ROOM_NUMBER">Room Number</label>
    			<div class="col-md-8">
    				<select id="ROOM_NUMBER" name="ROOM_NUMBER"class="form-control">
    				   
    				    
    				</select>
    			</div>
    		</div>
    	    
    	    
    	    
    	 </div>
	    
	    <div class = "col-sm-6">
			
			<div class="form-group">
    			<label class="col-md-4 control-label no-padding-right" for="bed_number">Bed Number</label>
    			<div class="col-md-8">
    				<select id="bed_number" name="bed_number"class="form-control">
    				    
    				</select>
    			</div>
    		</div>
			
				<div class="form-group">
				<label class="col-md-4 control-label no-padding-right" for="VALID_FROM"> Valid From </label>
				<div class="col-md-8">
					<input type="date" id="VALID_FROM" placeholder="" name="VALID_FROM" class="form-control">
					</div>
				</div>
		</div>
		
		
			<div class="center">
					<input type="submit" class="btn btn-sm btn-success" name="btnSubmit" value="Submit" style="margin-bottom:60px;">
			</div>
	</form>
			</div>
			
			<div class="col-xs-12">
				<div class="table-header">
											Results for "Student Entry"
										</div>
				<div>
					<div id="dynamic-table_wrapper" class="dataTables_wrapper form-inline no-footer">
						<div class="row">
							<div class="col-xs-6">
								<div class="dataTables_length" id="dynamic-table_length">
									<label>Display 
										<select name="dynamic-table_length" aria-controls="dynamic-table" class="form-control input-sm">
											<option value="10">10</option>
											<option value="25">25</option>
											<option value="50">50</option>
											<option value="100">100</option>
										</select> records
									</label>
								</div>
							</div>
							<div class="col-xs-6">
								<div id="dynamic-table_filter" class="dataTables_filter">
									<label>Search:
										<input type="text" name="search" id="search" class="form-control input-sm" placeholder="" aria-controls="dynamic-table">
										</label>
									</div>
								</div>
							</div>
							<table id="dynamic_table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="dynamic-table_info">
								<thead>
									<tr role="row">
										<th class="center sorting_disabled" rowspan="1" colspan="1" aria-label="">S.L</th>
										<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Domain: activate to sort column ascending">Student ID</th>
										<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Student Name</th>
										<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Building Name</th>
										<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Room No</th>
										<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Bed Rent</th>
										<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Bed Category</th>
										<th class="hidden-480 sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Clicks: activate to sort column ascending">Action</th>
									</tr>
								</thead>
								<tbody>
								    
								    <?php
								        $query = "SELECT ht_beds.BED_NO, ht_students.`HT_STUDENT_NO`, students.STUDENT_ID_NUMBER, students.STUDENT_NAME,ht_buildings.BUILDING_NAME, ht_rooms.ROOM_NUMBER,ht_beds.BED_RENT, ht_beds.BED_CATEGORY 
								        FROM ht_students LEFT JOIN ht_buildings ON ht_buildings.BUILDING_NO = ht_students.BUILDING_NO LEFT JOIN ht_rooms ON 
								        ht_rooms.ROOM_NO = ht_students.ROOM_NO LEFT JOIN ht_beds ON ht_students.BED_NO = ht_beds.BED_NO LEFT JOIN students ON 
								        students.STUDENT_NO = ht_students.STUDENT_NO WHERE ht_students.IS_DELETED =0" ;
								        $result = mysqli_query( $con , $query ) ;
								        $count = 1 ;
								        foreach( $result as $value )
								        {
								            echo "<tr>" ;
								                echo "<td>".$count ++ ."</td>" ;
								                echo "<td>".$value['STUDENT_ID_NUMBER']."</td>" ;
								                echo "<td>".$value['STUDENT_NAME']."</td>" ;
								                echo "<td>".$value['BUILDING_NAME']."</td>" ;
								                echo "<td>".$value['ROOM_NUMBER']."</td>" ;
								                echo "<td>".$value['BED_RENT']."</td>" ;
								                echo "<td>".$value['BED_CATEGORY']."</td>" ;
								                ?>
								                <td>
								                    <a class="btn btn-success" href="hostel_student_entry.php?edit= '<?php echo $value['HT_STUDENT_NO'];?>'"><i class="fa fa-pencil"></i>Edit</a>
								                    <a class="btn btn-danger" href="hostel_student_entry.php?delete= '<?php echo $value['HT_STUDENT_NO'];?>'"><i class="fa fa-trash"></i>Delete</a>
								                </td>
								                
								                <?php
								            echo "</tr>" ;
								        }
								    ?>
								    
								    
								</tbody>
							</table>
							<div class="row">
								<div class="col-xs-6">
									<div class="dataTables_info" id="dynamic-table_info" role="status" aria-live="polite">Showing 1 to 10 of <?php echo $count - 1 ;?> entries</div>
								</div>
								<div class="col-xs-6">
									<div class="dataTables_paginate paging_simple_numbers" id="dynamic-table_paginate">
										<ul class="pagination">
											<li class="paginate_button previous disabled" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_previous">
												<a href="#">Previous</a>
											</li>
											<li class="paginate_button active" aria-controls="dynamic-table" tabindex="0">
												<a href="#">1</a>
											</li>
											<li class="paginate_button " aria-controls="dynamic-table" tabindex="0">
												<a href="#">2</a>
											</li>
											<li class="paginate_button " aria-controls="dynamic-table" tabindex="0">
												<a href="#">3</a>
											</li>
											<li class="paginate_button next" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_next">
												<a href="#">Next</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
					    
<?php include('include/footer.php');?>	
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script>

    function delete() {
        return confirm('Delete entry?');
    }
    
    function getBedInformation(roomNo) 
    {
        $.ajax( { 
            url: "ajax/student_entry.php",
            method:"post",
            data: ({ "check":"check", "roomNo":roomNo }),
            dataType:"html",
            success: function( Data )
            {
                console.log( Data) ;
                $("#bed_number").html(Data) ;
            }
        }) ;
    }
    
    function getRoomNumber(BuildingNumber) 
    {
        $.ajax( { 
            url: "ajax/student_entry.php",
            method:"post",
            data: ({ "getBuildingNumber":"getBuildingNumber", "BuildingNumber":BuildingNumber }),
            dataType:"html",
            success: function( Data )
            {
                $("#ROOM_NUMBER").html(Data) ;
            }
        }) ;
    }
    
    $( document ).ready( function( ) {
        
        $("#ROOM_NUMBER").on("change", function( ) { 
            var room_no = $("#ROOM_NUMBER option:selected").val() ;
            // console.log(room_no);
            getBedInformation(room_no) ;
        }) ;
        
        $("#building_number").on("change", function( ) { 
            var BuildingNumber = $("#building_number option:selected").val() ;
            getRoomNumber( BuildingNumber ) ;
        }) ;
        
    }) ;
    
    $("#search").on("keyup",function(){
        
        var values=$(this).val();
        
        $("#dynamic_table tr").each(function(){
            
            var id=$(this).find("td").text();
                if(id.indexOf(values)!==0 && id.toLowerCase().indexOf(values.toLowerCase())<=0)
                {
                    
                    $(this).hide();
                }
                else{
                    $(this).show();
                }
            
        });
        
    });
    
</script>
