				<ul class="nav nav-list">
					<li class="active">
						<a href="index.html">
							<i class="menu-icon fa fa-tachometer"></i>
							<span class="menu-text"> Dashboard </span>
						</a>

						<b class="arrow"></b>
					</li>
                    	<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-building"></i>
							<span class="menu-text">Administration</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="deparment_setup.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Department Setup
								</a>

								<b class="arrow"></b>
							</li>
							</ul>
							</li>
							
							
                    	<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-book"></i>
							<span class="menu-text">Subject</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="subject_setup.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Subject Setup
								</a>

								<b class="arrow"></b>
							</li>
							</ul>
							</li>
                          <li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text">Batch</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="batch_setup.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Batch Setup
								</a>

								<b class="arrow"></b>
							</li>
							</ul>
							</li>
							
					  <li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-graduation-cap"></i>
							<span class="menu-text">Student</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="student_setup.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Student Setup
								</a>

								<b class="arrow"></b>
							</li>
							</ul>
							</li>
							
					 <li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-home"></i>
							<span class="menu-text">Class Room</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="class_room_setup.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Class Room Setup
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-home"></i>
							<span class="menu-text">Hostel</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						
						<ul class="submenu">
							<li class="">
								<a href="building_setup.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Building Setup
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
						<ul class="submenu">
							<li class="">
								<a href="hostel_room_setup.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Room Setup
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
						<ul class="submenu">
							<li class="">
								<a href="hostel_bed_setup.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Bed Setup
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
					
						<ul class="submenu">
							<li class="">
								<a href="hostel_student_entry.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Student Entry
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
						<ul class="submenu">
							<li class="">
								<a href="ht_daily_expense.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Daily Expenses
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					
					
				</ul><!-- /.nav-list -->

				<div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
					<i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
				</div>
			</div>