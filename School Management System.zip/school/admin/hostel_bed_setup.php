<?php include('include/header.php');?>
<?php include('include/menu.php');?>
<?php include('include/search.php');?>
 <!--ht_beds BED_NO ROOM_NO BED_RENT BED_CATEGORY IS_ACTIVE 	VALID_FROM 	IS_DELETED-->
<?php
    $cur = date("Y-m-d h:i:s") ;
    $msg = "" ;
    if( isset( $_POST['btnSubmit'] )  )
    {
        $ROOM_NUMBER = $_POST['ROOM_NUMBER'] ;
        $BED_CATEGORY = $_POST['BED_CATEGORY'] ;
        $BED_RENT = $_POST['BED_RENT'] ;
        $VALID_FROM = $_POST['VALID_FROM'] ;
        
        $query ="INSERT INTO ht_beds SET `ROOM_NO` = '$ROOM_NUMBER', `BED_RENT` = '$BED_RENT', `BED_CATEGORY` = '$BED_CATEGORY', `IS_ACTIVE` = 1 , `VALID_FROM` = '$VALID_FROM', `CREATED_ON` = '$cur'" ;
        $result = mysqli_query( $con , $query ) ;
        
        $msg = $result ? "inserted":"error";
    }
    

// <!--ht_beds BED_NO ROOM_NO BED_RENT BED_CATEGORY IS_ACTIVE 	VALID_FROM 	IS_DELETED-->
    if(isset($_POST['btnUpdate'])){
        $id = $_GET['edit'];
        $ROOM_NUMBER = $_POST['ROOM_NUMBER'] ;
        $BED_CATEGORY = $_POST['BED_CATEGORY'] ;
        $BED_RENT = $_POST['BED_RENT'] ;
        $VALID_FROM = $_POST['VALID_FROM'] ;
        
        $sql = "UPDATE ht_beds SET ROOM_NO='".$ROOM_NUMBER."',BED_CATEGORY='".$BED_CATEGORY."',BED_RENT='".$BED_RENT."',VALID_FROM='".$VALID_FROM."' WHERE 	BED_NO = '$id'";
        $query = mysqli_query($con,$sql);
        if($query){
            echo '<meta http-equiv="refresh" content="0";url=hostel_bed_setup.php>';
        }else{
            echo "not";
        }
    }
    
    if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    
        $sql = "UPDATE ht_beds SET IS_DELETED=1 WHERE BED_NO = '$id'";
        $query = mysqli_query($con,$sql);
        if($query){
            echo "<meta http-equiv='refresh' content=0;url=hostel_bed_setup.php>";
        }else{
            echo "not";
        }
    }


?>
    
<?php
    if(isset($_GET['edit'])):
        $id = $_GET['edit'];
        $sql = "SELECT * from ht_beds WHERE IS_DELETED=0 && BED_NO = '$id'";
    	 $query = mysqli_query($con,$sql);
    	 $row = mysqli_fetch_assoc($query);
?>

	<!--UPDATE FORM-->
	<div class = "col-xs-12">
	    <div class = "page-header">
	        <h1>Hostel Bed Setup Menu</h1>
	    </div>
	
		<form class="form-horizontal" role="form" action="" method="post">
		<div class = "col-sm-6">
    		<div class="form-group">
    			<label class="col-md-4 control-label no-padding-right" for="ROOM_NUMBER">Room Number</label>
    			<div class="col-md-8">
    				<select id="ROOM_NUMBER" name="ROOM_NUMBER"class="form-control">
    				    <option>Please Select one</option>
    				        <?php
    				            $query = "SELECT `ROOM_NUMBER` , `ROOM_NO` FROM ht_beds" ;
    				            $result = mysqli_query( $con , $query ) ;
    				            foreach( $result as $value )
    				            {
    				                echo "<option value = '".$value['ROOM_NO']."'>".$value['ROOM_NUMBER']."</option>";
    				            }
    				        ?>
    				    
    				</select>
    			</div>
    		</div>
    	    
    	    <div class="form-group">
    			<label class="col-md-4 control-label no-padding-right" for="BED_CATEGORY">Bed Category</label>
    			<div class="col-md-8">
    				<select id="BED_CATEGORY" name="BED_CATEGORY"class="form-control">
    				    <option>Please Select one</option>
    				    <option value ='Single' >Single</option>
    				    <option value ='Double'>Double</option>
    				    <option value ='Semi Double'> Semi Double</option>
    				</select>
    			</div>
    		</div>
	    </div>
	    
	    <div class = "col-sm-6">
			    <div class="form-group">
				<label class="col-md-4 control-label no-padding-right" for="BED_RENT"> Bed Rent </label>
				    <div class="col-md-8">
					    <input value="<?=@$row['BED_RENT']?>" type="text" id="BED_RENT" placeholder="" name="BED_RENT" class="form-control">
					</div>
				</div>
				
				<div class="form-group">
				<label class="col-md-4 control-label no-padding-right" for="VALID_FROM"> Valid From </label>
				<div class="col-md-8">
					<input type="date" id="VALID_FROM" placeholder="" name="VALID_FROM" class="form-control">
					</div>
				</div>
		</div>
		
		
			<div class="center">
					<input type="submit" class="btn btn-sm btn-success" name="btnUpdate" value="UPDATE" style="margin-bottom:60px;">
			</div>
	</form>
	</div>
	
<!--SUBMIT FORM-->

<?php 
else:	
?>

<div class="col-xs-12" > 
<!--style = "display:none-->
	<div class="page-header">
		<h1>Hostel Bed Setup</h1>
	</div>
	<form class="form-horizontal" role="form" action="" method="post">
		<div class = "col-sm-6">
    		<div class="form-group">
    			<label class="col-md-4 control-label no-padding-right" for="ROOM_NUMBER">Room Number</label>
    			<div class="col-md-8">
    				<select id="ROOM_NUMBER" name="ROOM_NUMBER"class="form-control">
    				    <option>Please Select one</option>
    				        <?php
    				            $query = "SELECT `ROOM_NUMBER` , `ROOM_NO` FROM ht_beds" ;
    				            $result = mysqli_query( $con , $query ) ;
    				            foreach( $result as $value )
    				            {
    				                echo "<option value = '".$value['ROOM_NO']."'>".$value['ROOM_NUMBER']."</option>";
    				            }
    				        ?>
    				    
    				</select>
    			</div>
    		</div>
    	    
    	    <div class="form-group">
    			<label class="col-md-4 control-label no-padding-right" for="BED_CATEGORY">Bed Category</label>
    			<div class="col-md-8">
    				<select id="BED_CATEGORY" name="BED_CATEGORY"class="form-control">
    				    <option>Please Select one</option>
    				    <option value ='Single' >Single</option>
    				    <option value ='Double'>Double</option>
    				    <option value ='Semi Double'> Semi Double</option>
    				</select>
    			</div>
    		</div>
	    </div>
	    
	    <div class = "col-sm-6">
			<div class="form-group">
				<label class="col-md-4 control-label no-padding-right" for="BED_RENT"> Bed Rent </label>
				<div class="col-md-8">
					<input type="text" id="BED_RENT" placeholder="" name="BED_RENT" class="form-control">
					</div>
				</div>
				
				<div class="form-group">
				<label class="col-md-4 control-label no-padding-right" for="VALID_FROM"> Valid From </label>
				<div class="col-md-8">
					<input type="date" id="VALID_FROM" placeholder="" name="VALID_FROM" class="form-control">
					</div>
				</div>
		</div>
		
		
			<div class="center">
					<input type="submit" class="btn btn-sm btn-success" name="btnSubmit" value="Submit" style="margin-bottom:60px;">
			</div>
	</form>
</div>

<?php
endif;
?>
			<div class="col-xs-12">
				<div class="table-header">
											Results for "Beds"
				</div>
				<div>
					<div id="dynamic-table_wrapper" class="dataTables_wrapper form-inline no-footer">
						<div class="row">
							<div class="col-xs-6">
								<div class="dataTables_length" id="dynamic-table_length">
									<label>Display 
										<select name="dynamic-table_length" aria-controls="dynamic-table" class="form-control input-sm">
											<option value="10">10</option>
											<option value="25">25</option>
											<option value="50">50</option>
											<option value="100">100</option>
										</select> records
									</label>
								</div>
							</div>
							<div class="col-xs-6">
								<div id="dynamic-table_filter" class="dataTables_filter">
									<label>Search:
										<input type="text" name="search" id="search" class="form-control input-sm" placeholder="" aria-controls="dynamic-table">
										</label>
									</div>
								</div>
							</div>
							<table id="dynamic_table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="dynamic-table_info">
								<thead>
									<tr role="row">
										<th class="center sorting_disabled" rowspan="1" colspan="1" aria-label="">S.L</th>
										<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Domain: activate to sort column ascending">Room Name</th>
										<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Bed Category</th>
										<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Bed Rent</th>
										<th class="sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending">Valid From</th>
										<th class="hidden-480 sorting" tabindex="0" aria-controls="dynamic-table" rowspan="1" colspan="1" aria-label="Clicks: activate to sort column ascending">Action</th>
									</tr>
								</thead>
								<tbody>
								    
								    <?php
            				            $query = "SELECT ht_rooms.`ROOM_NUMBER`, `BED_RENT`, `BED_CATEGORY`, `VALID_FROM`, `BED_NO` FROM ht_beds LEFT JOIN ht_rooms ON ht_rooms.ROOM_NO = ht_beds.ROOM_NO" ;
            				            $result = mysqli_query( $con , $query ) ;
            				            $count = 1;
            				            foreach( $result as $value )
            				            {
            				                echo "<tr>";
            				                    echo "<td>".$count ++."</td>" ;
            				                    echo "<td>".$value['ROOM_NUMBER']."</td>" ;
            				                    echo "<td>".$value['BED_CATEGORY']."</td>" ;
            				                    echo "<td>".$value['BED_RENT']."</td>" ;
            				                    echo "<td>".$value['VALID_FROM']."</td>" ;
            				                    echo "<td>";
            				                        echo "<a class = 'btn btn-success' href = 'hostel_bed_setup.php?edit = '".$value['BED_NO']."' ><i class = 'fa fa-pencil'></i>Edit</a>";
            				                        echo "<a class = 'btn btn-danger' href = 'hostel_bed_setup.php?delete = '".$value['BED_NO']."' ><i class = 'fa fa-trash'></i>Delete</a>";
            				                    echo "</td>" ;
            				                echo "</tr>";
            				            }
    				                ?>
								    
								</tbody>
							</table>
							<div class="row">
								<div class="col-xs-6">
									<div class="dataTables_info" id="dynamic-table_info" role="status" aria-live="polite">Showing 1 to 10 of 23 entries</div>
								</div>
								<div class="col-xs-6">
									<div class="dataTables_paginate paging_simple_numbers" id="dynamic-table_paginate">
										<ul class="pagination">
											<li class="paginate_button previous disabled" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_previous">
												<a href="#">Previous</a>
											</li>
											<li class="paginate_button active" aria-controls="dynamic-table" tabindex="0">
												<a href="#">1</a>
											</li>
											<li class="paginate_button " aria-controls="dynamic-table" tabindex="0">
												<a href="#">2</a>
											</li>
											<li class="paginate_button " aria-controls="dynamic-table" tabindex="0">
												<a href="#">3</a>
											</li>
											<li class="paginate_button next" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_next">
												<a href="#">Next</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
					    
<?php include('include/footer.php');?>	


<script>
    $("#search").on("keyup",function(){
        
        var values=$(this).val();
        
        $("#dynamic_table tr").each(function(){
            
            var id=$(this).find("td").text();
                if(id.indexOf(values)!==0 && id.toLowerCase().indexOf(values.toLowerCase())<=0)
                {
                    
                    $(this).hide();
                }
                else{
                    $(this).show();
                }
            
        });
        
    });
    
</script>
