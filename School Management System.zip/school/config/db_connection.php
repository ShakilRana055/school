<?php
    date_default_timezone_set("Asia/Dhaka");
	$dbname = "bdabashon_school";
	$hostname = "localhost";
	$username = "bdabashon_admins";
	$password = "asdf@1234";
	$con = mysqli_connect($hostname, $username, $password, $dbname );
	mysqli_set_charset($con, "utf8");
?>
